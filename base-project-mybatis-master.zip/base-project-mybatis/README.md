﻿## base-project-mybatis
**基于`springboot2` + `springsecurity` + `mybatis` + `redis` + `swagger` 的脚手架工程**